directory to hold data files
